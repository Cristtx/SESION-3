package pe.edu.upeu.cine.control;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Modality;
import javafx.stage.Stage;
import pe.edu.upeu.cine.modelo.Asiento;
import pe.edu.upeu.cine.modelo.Funcion;
import pe.edu.upeu.cine.modelo.Venta;
import pe.edu.upeu.cine.repositorio.AsientoFuncionRepositorio;
import pe.edu.upeu.cine.repositorio.FuncionRepositorio;
import pe.edu.upeu.cine.repositorio.VentaRepositorio;

import java.util.ArrayList;
import java.util.List;

public class VentaController {

    // ---------- ELEMENTOS DE LA VISTA ----------
    @FXML private ComboBox<Funcion> cmbFuncion;
    @FXML private TextField txtPrecio;
    @FXML private Spinner<Integer> spnCantidad;
    @FXML private TextField txtTotal;
    @FXML private TextField txtAsientos;

    @FXML private TableView<Venta> tablaVentas;
    @FXML private TableColumn<Venta, Integer> colId;
    @FXML private TableColumn<Venta, String> colPelicula;
    @FXML private TableColumn<Venta, String> colFecha;
    @FXML private TableColumn<Venta, String> colHora;
    @FXML private TableColumn<Venta, Integer> colCantidad;
    @FXML private TableColumn<Venta, Double> colTotal;

    // ---------- REPOSITORIOS ----------
    private final FuncionRepositorio funcionRepo = new FuncionRepositorio();
    private final VentaRepositorio ventaRepo = new VentaRepositorio();
    private final AsientoFuncionRepositorio asientoFuncionRepo = new AsientoFuncionRepositorio();

    // Lista de asientos seleccionados en el popup
    private List<Asiento> asientosSeleccionados = new ArrayList<>();


    // ---------- INICIALIZAR ----------
    @FXML
    public void initialize() {
        cargarFunciones();
        configurarSpinner();
        configurarTabla();
        cargarVentas();
    }


    // ---------- CARGAR FUNCIONES ----------
    private void cargarFunciones() {
        List<Funcion> funciones = funcionRepo.listar();
        cmbFuncion.setItems(FXCollections.observableArrayList(funciones));

        cmbFuncion.setOnAction(e -> {
            Funcion f = cmbFuncion.getValue();
            if (f != null) {
                txtPrecio.setText(String.valueOf(f.getPrecio()));
                calcularTotal();
            }
        });
    }


    // ---------- CONFIG SPINNER ----------
    private void configurarSpinner() {
        SpinnerValueFactory<Integer> valueFactory =
                new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 3, 1);

        spnCantidad.setValueFactory(valueFactory);

        spnCantidad.valueProperty().addListener((obs, oldVal, newVal) -> calcularTotal());
    }


    // ---------- CALCULAR TOTAL ----------
    private void calcularTotal() {
        try {
            Funcion f = cmbFuncion.getValue();
            if (f != null) {
                int cantidad = spnCantidad.getValue();
                double total = f.getPrecio() * cantidad;
                txtTotal.setText(String.valueOf(total));
            }
        } catch (Exception ignored) {}
    }


    // ---------- ABRIR POPUP DE ASIENTOS ----------
    @FXML
    private void abrirAsientos() {
        Funcion f = cmbFuncion.getValue();

        if (f == null) {
            mostrar("Seleccione una función primero.");
            return;
        }

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/AsientosView.fxml"));
            Parent root = loader.load();

            AsientosController controller = loader.getController();
            controller.setFuncion(f.getIdFuncion());

            controller.setListener(asientos -> {
                asientosSeleccionados = asientos;

                String texto = asientos.stream()
                        .map(Asiento::getCodigo)
                        .reduce((a, b) -> a + ", " + b)
                        .orElse("");

                txtAsientos.setText(texto);
            });

            Stage stage = new Stage();
            stage.setTitle("Seleccionar Asientos");
            stage.setScene(new Scene(root));
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.showAndWait();

        } catch (Exception e) {
            e.printStackTrace();
            mostrar("Error al abrir vista de asientos.");
        }
    }


    // ---------- REGISTRAR VENTA ----------
    @FXML
    private void venderBoleto() {

        Funcion f = cmbFuncion.getValue();
        if (f == null) {
            mostrar("Seleccione una función.");
            return;
        }

        if (asientosSeleccionados.isEmpty()) {
            mostrar("Seleccione los asientos.");
            return;
        }

        int cantidad = spnCantidad.getValue();

        if (asientosSeleccionados.size() != cantidad) {
            mostrar("La cantidad debe coincidir con los asientos seleccionados.");
            return;
        }

        try {
            double total = Double.parseDouble(txtTotal.getText());

            Venta v = new Venta();
            v.setIdFuncion(f.getIdFuncion());
            v.setCantidad(cantidad);
            v.setTotal(total);

            ventaRepo.registrar(v);

            // Registrar asientos ocupados
            for (Asiento a : asientosSeleccionados) {
                asientoFuncionRepo.registrarAsientoOcupado(f.getIdFuncion(), a.getIdAsiento());
            }

            mostrar("Venta registrada correctamente.");
            limpiarFormulario();
            cargarVentas();

        } catch (Exception e) {
            e.printStackTrace();
            mostrar("Error al registrar venta.");
        }
    }


    // ---------- CARGAR TABLA ----------
    private void configurarTabla() {
        colId.setCellValueFactory(v -> v.getValue().idVentaProperty().asObject());
        colPelicula.setCellValueFactory(v -> v.getValue().peliculaProperty());
        colFecha.setCellValueFactory(v -> v.getValue().fechaProperty());
        colHora.setCellValueFactory(v -> v.getValue().horaProperty());
        colCantidad.setCellValueFactory(v -> v.getValue().cantidadProperty().asObject());
        colTotal.setCellValueFactory(v -> v.getValue().totalProperty().asObject());
    }

    private void cargarVentas() {
        tablaVentas.setItems(FXCollections.observableArrayList(ventaRepo.listar()));
    }


    // ---------- LIMPIAR ----------
    private void limpiarFormulario() {
        cmbFuncion.getSelectionModel().clearSelection();
        txtPrecio.clear();
        txtTotal.clear();
        txtAsientos.clear();
        asientosSeleccionados.clear();
        spnCantidad.getValueFactory().setValue(1);
    }


    // ---------- ALERTAS ----------
    private void mostrar(String msg) {
        Alert a = new Alert(Alert.AlertType.INFORMATION);
        a.setHeaderText(null);
        a.setContentText(msg);
        a.showAndWait();
    }
}
