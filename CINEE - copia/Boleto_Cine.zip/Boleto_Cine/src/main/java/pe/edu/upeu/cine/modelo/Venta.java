package pe.edu.upeu.cine.modelo;

import javafx.beans.property.*;

public class Venta {

    private IntegerProperty idVenta = new SimpleIntegerProperty();
    private IntegerProperty idFuncion = new SimpleIntegerProperty();
    private IntegerProperty cantidad = new SimpleIntegerProperty();
    private DoubleProperty total = new SimpleDoubleProperty();

    private StringProperty pelicula = new SimpleStringProperty();
    private StringProperty fecha = new SimpleStringProperty();
    private StringProperty hora = new SimpleStringProperty();

    // ---------------- GETTERS Y SETTERS ----------------

    public int getIdVenta() {
        return idVenta.get();
    }

    public void setIdVenta(int id) {
        this.idVenta.set(id);
    }

    public IntegerProperty idVentaProperty() {
        return idVenta;
    }

    public int getIdFuncion() {
        return idFuncion.get();
    }

    public void setIdFuncion(int id) {
        this.idFuncion.set(id);
    }

    public IntegerProperty idFuncionProperty() {
        return idFuncion;
    }

    public int getCantidad() {
        return cantidad.get();
    }

    public void setCantidad(int c) {
        this.cantidad.set(c);
    }

    public IntegerProperty cantidadProperty() {
        return cantidad;
    }

    public double getTotal() {
        return total.get();
    }

    public void setTotal(double t) {
        this.total.set(t);
    }

    public DoubleProperty totalProperty() {
        return total;
    }

    public String getPelicula() {
        return pelicula.get();
    }

    public void setPelicula(String p) {
        this.pelicula.set(p);
    }

    public StringProperty peliculaProperty() {
        return pelicula;
    }

    public String getFecha() {
        return fecha.get();
    }

    public void setFecha(String f) {
        this.fecha.set(f);
    }

    public StringProperty fechaProperty() {
        return fecha;
    }

    public String getHora() {
        return hora.get();
    }

    public void setHora(String h) {
        this.hora.set(h);
    }

    public StringProperty horaProperty() {
        return hora;
    }

}
